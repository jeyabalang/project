const express = require("express");
const app = express();
const path = require("path");
const router = express.Router();


router.get("/", (req, res) => {
  res.render("index.pug");
});

app.set("view engine", "pug");
app.set("express", path.join(__dirname, "express"));


router.get("/about", (req, res) => {
  res.render("about", { title: "Hey", message: "Hello there!" });
});

app.use("/", router);
app.listen(process.env.port || 3000);

console.log("Running at Port 3000");
